package de.fiduciagad.mytests;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.fluent.Request;
import org.apache.http.client.fluent.Response;
import org.apache.http.entity.ContentType;

import com.google.api.client.util.Lists;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import de.fiduciagad.ari.projekt.controller.MyEventBuilder;
import de.fiduciagad.ari.projekt.model.MyEvent;

public class HttpClientTestMain
{

    public static void main(String[] args) throws ClientProtocolException, IOException
    {

        MyEvent mye = new MyEventBuilder().build();
        ArrayList<MyEvent> newArrayList = Lists.newArrayList();
        newArrayList.add(new MyEventBuilder().desc("Cloud Arbeit").build());
        newArrayList.add(new MyEventBuilder().desc("Test Software").build());
        mye.setNewEvents(newArrayList);

        Gson gson = new GsonBuilder().create();
        String json = gson.toJson(mye.getNewEvents());
        
        Response execute = Request.Post("http://kikalender.nspeed.rz.bankenit.de/predict").bodyString(json,
            ContentType.APPLICATION_JSON).execute();

        String asString = execute.returnContent().asString();
        System.out.println(asString);
    }

}
